/**
 * Created by asimcraft on 11/11/16.
 */
//this is the modal ( json ) for the designers. Personal use data will be here

var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var DesignerSchema = new Schema({
        name : String
    });
// export the designer Schema and its properties
module.exports = mongoose.model('Designer', DesignerSchema);
